#!/usr/bin/env bash
set -euo pipefail
uv sync --group dev --reinstall-package xpool --no-build-isolation-package xpool \
  --config-settings-package xpool:cmake.define.XPOOL_CUDA_ARCHITECTURES=80-real
uv run --no-sync xtest list --suite e2e \
  'tests/suites/e2e/sglang/test_e2e_model_serving.py::test_e2e_model_serving[serving-001-decode-full-prefill-breakable]'
