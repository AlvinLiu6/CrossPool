# Timeline qualification batch

Prepare the managed environment before a reservation:

```bash
bash local_scripts/timeline/prepare.sh
```

Provide a CrossPool config resolving `Qwen/Qwen3-0.6B` to an existing checkpoint.
Reserve exactly two devices and run one batch, with the attention UUID first:

```bash
uv run --no-sync python local_scripts/timeline/run.py \
  --config /path/to/xpool.toml \
  --devices GPU-ATTENTION-UUID GPU-FFN-UUID \
  --output /path/to/new-evidence --repeats 3
```

The batch executes only `serving-001`, using the canonical supervisor. It compares
Timeline disabled/enabled and a disk-limit case, preserves separate Sessions and
Attempts, logs stdout/stderr, and writes raw artifacts plus per-domain Perfetto
files and quality reports. Existing serving qualification enables the legacy
Observers in both comparison modes; measured differences isolate Timeline added
cost, rather than claiming a legacy-Observer-free baseline.

CrossPool owns attention MPS. The batch does not adopt, manually start or stop
controllers. It never uses `/home/incoming`. Unverified cleanup stops the batch;
inspect the retained test result directory before further device use. Nothing is
automatically deleted or bundled from a potentially live run.

Return the whole retired evidence directory, including failures, `executions.json`,
`source.patch`, `source-files.json`, the explicit config, raw Sessions, derived files and xtest artifacts. Preserve the exact
checkout including untracked implementation files when transferring it. Review
request timing, throughput, records, file bytes, losses, shared Transport identity
and Lease reuse against those original artifacts. `measurements.json` links the exact inference and startup-inclusive timing
artifacts and lists unavailable metrics. `collection.json` reports record/file
bytes and per-Producer counters. Stage two does not acquire HTTP/Token timing
boundaries or peak-memory samples, so the batch does not infer TTFT, TPOT or
throughput from total test duration. Wall-clock batch execution is
not a serving-latency measurement. Clock calibration and MoE qualification remain
outside this batch.
