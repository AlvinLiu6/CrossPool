"""User-run two-device batch; retains failed artifacts and verified cleanup boundaries."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

from pydantic import BaseModel

from xpool.config import XpoolConfig
from xpool.devkit.timeline.models import Quality
from xpool.devkit.timeline.offline import export, verify
from xpool.model import ModelId
from xtest.harness.report import TestRunResults

SELECTOR = (
    "tests/suites/e2e/sglang/test_e2e_model_serving.py::"
    "test_e2e_model_serving[serving-001-decode-full-prefill-breakable]"
)


class Execution(BaseModel):
    """One independent execution; no merging of Sessions or failed Attempts."""

    mode: str
    repeat: int
    command: list[str]
    returncode: int
    elapsed_s: float
    cleanup_verified: bool
    sessions: list[str]


def permitted(path: Path) -> Path:
    """Exclude operator-forbidden paths without creating or modifying them."""
    resolved = path.resolve()
    if resolved.is_relative_to(Path("/home/incoming")):
        raise ValueError("restricted path")
    return resolved


def run(config: Path, devices: list[str], output: Path, repeats: int, diagnostics: bool = False) -> int:
    """Use the canonical serving supervisor and stop after unverified cleanup."""
    config, output = permitted(config), permitted(output)
    resolved = XpoolConfig.from_file(config, env={})
    permitted(resolved.model_path_of(ModelId("Qwen/Qwen3-0.6B")))
    if len(devices) != 2 or len(set(devices)) != 2 or any(not value.startswith("GPU-") for value in devices):
        raise ValueError("exactly two distinct full GPU UUIDs are required, attention first")
    output.mkdir(parents=True, exist_ok=False)
    (output / "source.patch").write_bytes(subprocess.check_output(["git", "diff", "HEAD"]))
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    (output / "revision.txt").write_text(revision + "\n", encoding="utf-8")
    inventory = subprocess.check_output(["git", "ls-files", "-c", "-o", "--exclude-standard"], text=True).splitlines()
    source_hashes = {
        name: hashlib.sha256(Path(name).read_bytes()).hexdigest()
        for name in inventory
        if Path(name).is_file() and not Path(name).is_symlink()
    }
    (output / "source-files.json").write_text(json.dumps(source_hashes, indent=2), encoding="utf-8")
    (output / "config.toml").write_bytes(config.read_bytes())
    outcomes: list[Execution] = []
    failed = False
    for mode in ("disabled", "enabled", "disk-limit"):
        for repeat in range(repeats if mode != "disk-limit" else 1):
            destination = output / f"{mode}-{repeat}"
            destination.mkdir()
            environment = {name: value for name, value in os.environ.items() if not name.startswith("XPOOL_")}
            environment.pop("UV_ENV_FILE", None)
            environment.pop("CUDA_MPS_PIPE_DIRECTORY", None)
            environment.pop("CUDA_MPS_LOG_DIRECTORY", None)
            environment["CUDA_VISIBLE_DEVICES"] = ",".join(devices)
            environment["XPOOL_CONFIG"] = str(config)
            environment["XPOOL_DEBUG_TIMELINE_DIAGNOSTICS"] = "1" if diagnostics else "0"
            environment["XPOOL_DEBUG_TIMELINE_ENABLE"] = "0" if mode == "disabled" else "1"
            if mode != "disabled":
                environment["XPOOL_DEBUG_TIMELINE_OUTDIR"] = str(destination / "raw")
            if mode == "disk-limit":
                environment["XPOOL_DEBUG_TIMELINE_SESSION_MAX_BYTES"] = str(12 << 20)
            command = [
                "uv",
                "run",
                "--no-sync",
                "xtest",
                "run",
                "--suite",
                "e2e",
                "--strict-requirements",
                "--result-root",
                str(destination / "xtest"),
                SELECTOR,
            ]
            started = time.monotonic()
            with (destination / "execution.log").open("wb") as log:
                with subprocess.Popen(
                    command, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
                ) as process:
                    if process.stdout is None:
                        raise RuntimeError("batch child stdout unavailable")
                    for line in process.stdout:
                        log.write(line)
                        log.flush()
                        print(line.decode(errors="replace"), end="", flush=True)
                    returncode = process.wait()
            results = list((destination / "xtest").glob("*/results.json"))
            cleanup = bool(results) and all(
                (result := TestRunResults.model_validate_json(path.read_bytes())).finished
                and result.cleanup_verified is True
                for path in results
            )
            sessions = list((destination / "raw").glob("*/manifest.json"))
            outcome = Execution(
                mode=mode,
                repeat=repeat,
                command=command,
                returncode=returncode,
                elapsed_s=time.monotonic() - started,
                cleanup_verified=cleanup,
                sessions=[str(path.parent.relative_to(output)) for path in sessions],
            )
            outcomes.append(outcome)
            failed |= returncode != 0
            if cleanup:
                for manifest in sessions:
                    derived = destination / "derived" / manifest.parent.name
                    derived.parent.mkdir(exist_ok=True)
                    try:
                        report = export(manifest.parent, derived)
                        summaries = {
                            str(path.parent.name): Quality.model_validate_json(path.read_bytes()).model_dump(
                                mode="json"
                            )
                            for path in manifest.parent.glob("producer-*/summary.json")
                        }
                        (derived / "collection.json").write_text(
                            json.dumps(
                                {
                                    "published_records": report.records,
                                    "published_chunk_bytes": report.bytes,
                                    "session_file_bytes": sum(
                                        path.stat().st_size for path in manifest.parent.rglob("*") if path.is_file()
                                    ),
                                    "producer_quality": summaries,
                                },
                                indent=2,
                            ),
                            encoding="utf-8",
                        )
                        if mode == "enabled" and not report.complete:
                            failed = True
                    except (OSError, ValueError) as error:
                        failed = True
                        (destination / f"{manifest.parent.name}.error.txt").write_text(str(error), encoding="utf-8")
                if mode != "disabled" and not sessions:
                    failed = True
            else:
                failed = True
            (output / "executions.json").write_text(
                json.dumps([value.model_dump() for value in outcomes], indent=2), encoding="utf-8"
            )
            if not cleanup:
                print(f"cleanup unverified; stop reservation work and inspect retained owners: {destination}")
                return 1
    # Retain the original request/response and startup-inclusive timings. Stage
    # two has no HTTP/Token boundaries, so it cannot derive TTFT or Decode TPOT.
    evidence_paths = {
        name: [str(path.relative_to(output)) for path in output.rglob(name)]
        for name in ("inference.json", "sglang.duration.json", "collection.json")
    }
    (output / "measurements.json").write_text(
        json.dumps(
            {
                "source_artifacts": evidence_paths,
                "unavailable": [
                    "ttft",
                    "decode_tpot",
                    "throughput",
                    "cpu_gpu_peak_memory",
                    "isolated_submit_transfer_write_cost",
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    # Normal modes require complete coverage; quota pressure requires explicit
    # degradation with surviving structurally valid evidence, not a test failure.
    for outcome in outcomes:
        if outcome.mode == "disk-limit":
            for relative in outcome.sessions:
                try:
                    report = verify(output / relative)
                except (OSError, ValueError) as error:
                    failed = True
                    print(f"disk-limit artifact invalid session={relative} detail={error}")
                    continue
                if "disk_limit" not in {issue.reason for issue in report.issues}:
                    failed = True
    return 1 if failed else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="two-device Timeline qualification batch")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--devices", required=True, nargs=2)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--diagnostics", action="store_true", help="verbose operation logs; affects timings")
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error("repeats must be positive")
    return run(args.config, args.devices, args.output, args.repeats, args.diagnostics)


if __name__ == "__main__":
    raise SystemExit(main())
